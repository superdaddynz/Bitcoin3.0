Sample configuration files for:
```
SystemD: bitcoin3d.service
Upstart: bitcoin3d.conf
OpenRC:  bitcoin3d.openrc
         bitcoin3d.openrcconf
CentOS:  bitcoin3d.init
macOS:    org.bitcoin3.bitcoin3d.plist
```
have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
